package com.teamviewer.uni_todo.UniTodoSpring.repositories;

import com.teamviewer.uni_todo.UniTodoSpring.domains.UserDomain;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface UserRepository extends CrudRepository<UserDomain, Integer> {
    Optional<UserDomain> findByUsername(String username);
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);
}
