package com.teamviewer.uni_todo.UniTodoSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniTodoSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(UniTodoSpringApplication.class, args);
	}

}
